<?php
include('_dbconnect.php');
if(isset($_POST['insert_product'])){
    $product_title=$_POST['product_title'];
    $product_description=$_POST['product_description'];
    $product_Size=$_POST['product_Size'];
    $product_Quantity=$_POST['product_Quantity'];
    $product_Color=$_POST['product_Color'];
     $product_Price=$_POST['product_Price'];
    $product_status='true';

    $product_image1=$_FILES['product_image1']['name'];
    $product_image2=$_FILES['product_image2']['name'];
    $product_image3=$_FILES['product_image3']['name'];
    $product_image4=$_FILES['product_image4']['name'];

    // Accessing image tmp name
    $temp_image1 = $_FILES['product_image1']['tmp_name'];
    $temp_image2 = $_FILES['product_image2']['tmp_name'];
    $temp_image3 = $_FILES['product_image3']['tmp_name'];
    $temp_image4 = $_FILES['product_image4']['tmp_name'];

    //checking empty condition
    if($product_title == '' or $product_description == ''or $product_image1=='' or $product_image2=='' or $product_image3=='' 
    or $product_image4==''or $product_Size == '' or $product_Quantity == '' or $product_Color == ''or $product_Price==''
    or $product_status=='' ) {
        echo "<script>alert('Please fill all the available fields')</script>";
        exit();
    } else {
        move_uploaded_file($temp_image1,"./productimg/$product_image1");
        move_uploaded_file($temp_image2,"./productimg/$product_image2");
        move_uploaded_file($temp_image3,"./productimg/$product_image3");
        move_uploaded_file($temp_image4,"./productimg/$product_image4");
        //insert query
        $insert_products="insert into `products`(product_title,product_description,product_image1,product_image2,product_image3,product_image4,
            product_size,product_quantity,product_color,product_price,date,status) values (  '$product_title', '$product_description',
            '$product_image1', '$product_image2', '$product_image3','$product_image4',' $product_Size',' $product_Quantity', '$product_Color',
            '$product_Price', NOW(), ' $product_status') ";
         $result_query=mysqli_query($conn,$insert_products);
        if($result_query){
            echo "<script>alert('Successfully inserted the product')</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>insertproduct</title>
    <link rel="stylesheet" href="css/bootstrap.min.css.map">
    <link rel="stylesheet" href="adminstyle.css">
    <link rel="stylesheet" href="media.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
    /* Custom CSS */
    .container {
      max-width: 1000px;
      margin: auto;
    }
  </style>
</head>
<body>

    <!-- Main Content -->
  <div class="container mt-4">
    <h1 class="text-center">Insert Product</h1>
    <!-- Product Form -->
    <div class="card">
      <div class="card-header">
        Add New Product
      </div>
      <div class="card-body">
      <form action="" method="post" enctype="multipart/form-data">
          <div class="form-group">
            <label for="productName">Product Name</label>
            <input type="text" class="form-control" name="product_title"id="product_title" placeholder="Enter product name">
          </div>
          <div class="form-group">
            <label for="description">Description</label>
            <input type="text" name="product_description" class="form-control" id="product_description" placeholder="Enter product description">
          </div>
          <div class="form-group">
            <label for="product_Image1" class="form-label">Product Image1</label>
            <input type="file" class="form-control" id="product_image1" name="product_image1" required="required">
          </div>
          <div class="form-group">
            <label for="product_Image1" class="form-label">Product Image2</label>
            <input type="file" class="form-control" id="product_image2" name="product_image2" required="required">
          </div>
          <div class="form-group">
            <label for="product_Image1" class="form-label">Product Image3</label>
            <input type="file" class="form-control" id="product_image3" name="product_image3" required="required">
          </div>
          <div class="form-group">
            <label for="product_Image1" class="form-label">Product Image4</label>
            <input type="file" class="form-control" id="product_image4" name="product_image4" required="required">
          </div>
          <div class="form-group">
            <label for="productSize">Size</label>
            <input type="text" class="form-control"  name="product_Size"id="product_Size" placeholder="Enter product size">
          </div>
          <div class="form-group">
            <label for="productQuantity">Quantity</label>
            <input type="number" class="form-control"name="product_Quantity" id="product_Quantity" placeholder="Enter product quantity">
          </div>
          <div class="form-group">
            <label for="productColor">Color</label>
            <input type="text" class="form-control"name="product_Color" id="product_Color" placeholder="Enter product color">
          </div>
          <div class="form-group">
            <label for="productPrice">Price</label>
            <input type="number" class="form-control"name="product_Price" id="product_Price" placeholder="Enter product price">
          </div>
          <button type="submit"  name="insert_product"class="btn btn-primary">Submit</button>
        </form>
      </div>
    </div>

   