<?php

include('header.php');
if(!isset($_SESSION['admin_logged_in'])){
  header('location: adminlogin.php');
  exit();
}
//get order

  $stmt = $conn->prepare("SELECT * FROM orders ");
  $stmt->execute();

  $orders = $stmt->get_result();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css.map">
    <link rel="stylesheet" href="adminstyle.css">
    <link rel="stylesheet" href="media.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
<?php include('sidebar.php');?>
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <h2>Orders</h2>
                <?php if (isset($_GET['order_updated'])) { ?>
                    <p class="text-center" style="color: green;"><?php echo ($_GET['order_updated']); ?></p>
                <?php } ?>
                <?php if (isset($_GET['order_failed'])) { ?>
                    <p class="text-center" style="color: red;"><?php echo ($_GET['order_failed']); ?></p>
                <?php } ?>
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th scope="col">Order Id</th>
                    <th scope="col">Order Status</th>
                    <th scope="col">User Id</th>
                    <th scope="col">Order Date</th>
                    <th scope="col">User Phone</th>
                    <th scope="col">User Address</th>
                    <th scope="col">Edit</th>
                    <th scope="col">Delete</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($orders as $order){?>
                <tr>
                    <td><?php echo $order['order_id'];?></td>
                    <td><?php echo $order['order_status'];?></td>
                    <td><?php echo $order['user_id'];?></td>
                    <td><?php echo $order['order_date'];?></td>
                    <td><?php echo $order['user_phone'];?></td>
                    <td><?php echo $order['user_address'];?></td>
                    <td><a class="btn btn-primary" href="edit_order.php?order_id=<?php echo $order['order_id'];?>">Edit</a></td>
                    <td><a class="btn btn-danger" href="delete_order.php?order_id=<?php echo $order['order_id'];?>">Delete</a></td>  
                </tr>
                <?php }?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>
</html>
