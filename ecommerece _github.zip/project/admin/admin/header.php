<?php
session_start();
include('_dbconnect.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>insertproduct</title>
    <link rel="stylesheet" href="css/bootstrap.min.css.map">
    <link rel="stylesheet" href="adminstyle.css">
    <link rel="stylesheet" href="media.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
  <a class ="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="#">fashion mart </a>
  <button class="navbar-toggler position-adsolute d-md-none collapsed" type="button">
  <span class="navbar-toggler-icon"></span>
</button>
  <div class="navbar-nav">
    <div class="nav-item text-nowrap">
        <?php if (Isset($_SESSION['admin_logged_in'])){?>
    <a class="nav-link px-3" href="adminlogout.php">Sign out</a>
    <?php }?>
</div>
</div>
</header>
<!-- jquery-->
   <script src="js/jquery-3.7.1.js"></script>
   <!--bootstrap js-->
  <!-- <script src=" js/bootstrap.bundle.min.js"></script>-->
 <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
  integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>-->
 <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
   <!--custom js-->
   <script src=" "></script>