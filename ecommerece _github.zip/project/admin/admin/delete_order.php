<?php
session_start();
include('_dbconnect.php');
include('header.php');

if (!isset($_SESSION['admin_logged_in'])) {
    header('location: adminlogin.php');
    exit();
}

if (isset($_GET['order_id'])) {
    $order_id = $_GET['order_id'];
    $stmt = $con->prepare("DELETE FROM orders WHERE order_id = ?");
    $stmt->bind_param('i', $order_id);

    if ($stmt->execute()) {
        header('location: admindata.php?deleted_successfully=Order has been deleted successfully');
    } else {
        header('location: admindata.php?deleted_failure=Could not delete order');
    }
    $stmt->close();
    exit();
} else {
    header('location: admindata.php?deleted_failure=Invalid order ID');
    exit();
}
?>
