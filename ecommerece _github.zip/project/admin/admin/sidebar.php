<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <style>
    /* Custom CSS */
.bd-placeholder-img {
  font-size: 1.125rem;
}

/* Sidebar */
.sidebar {
  position: fixed;
  top: 0;
  left: 0;
  height: 100%;
  width: 250px;
  background-color: #f8f9fa;
  padding-top: 56px;
  z-index: 1000;
  transition: all 0.3s;
}

/* Sidebar links */
.sidebar .nav-link {
  padding: 10px 15px;
  text-decoration: none;
  display: block;
  color: #333;
}

/* Sidebar links on hover */
.sidebar .nav-link:hover {
  background-color: #e9ecef;
}

/* Main content */
.main-content {
  margin-left: 250px; /* Adjust this value according to the width of your sidebar */
}

/* Page title */
.page-title {
  margin-top: 20px;
  margin-bottom: 20px;
}

/* Button group */
.btn-group {
  margin-right: 10px;
}

/* Adjustments for small devices */
@media (max-width: 768px) {
  .sidebar {
    width: 100%;
    padding-top: 10px;
    position: static;
    height: auto;
    background-color: #333;
  }
  .main-content {
    margin-left: 0;
  }
}

  </style>
</head>
<body>
  <div class="container-fluid">
    <div class="row" style="min-height: 1000px">
      <!-- Sidebar -->
      <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
        <div class="position-sticky pt-3">
          <ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="admindata.php">
                <span data-feather="home"></span>
                Dashboard
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="admindata.php">
                <span data-feather="file"></span>
                Orders
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="products.php">
                <span data-feather="shopping-cart"></span>
                Products
              </a>
            </li>
          
            <li class="nav-item">
              <a class="nav-link" href="account.php">
                <span data-feather="bar-chart-2"></span>
             Account
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="admininserproduct.php">
                <span data-feather="layers"></span>
                Add New Product
              </a>
            </li>
          </ul>
        </div>
      </nav>
      <!-- Main content -->
      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
        <h1 class="h2">Dashboard</h1>
    </div>


  <!-- Bootstrap JS (optional, for some functionalities) -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
