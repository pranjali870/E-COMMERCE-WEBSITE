<?php
session_start();

// Unset admin session variables
unset($_SESSION['admin_logged_in']);
unset($_SESSION['admin_email']);
unset($_SESSION['admin_name']);

// Redirect to admin login page
header('Location: adminlogin.php');
exit;
?>
