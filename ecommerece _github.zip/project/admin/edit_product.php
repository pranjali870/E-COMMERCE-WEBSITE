<?php
include('header.php');
if (!isset($_SESSION['admin_logged_in'])) {
    header('location: adminlogin.php');
    exit();
}

// Check if product_id is set in the URL
if (isset($_GET['product_id'])) {
    $product_id = $_GET['product_id'];
    $stmt = $conn->prepare("SELECT * FROM products WHERE product_id = ?");
    $stmt->bind_param('i', $product_id);
    $stmt->execute();
    $products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} else if (isset($_POST['update_btn'])) {
    $product_id = $_POST['product_id'];
    $title = $_POST['product_title'];
    $description = $_POST['product_description'];
    $size = $_POST['product_Size'];
    $quantity = $_POST['product_Quantity'];
    $color = $_POST['product_Color'];
    $price = $_POST['product_Price'];

    $stmt = $conn->prepare("UPDATE products SET product_title=?, product_description=?, product_size=?, product_quantity=?, product_color=?, product_price=? WHERE product_id=?");
    $stmt->bind_param('ssssssi', $title, $description, $size, $quantity, $color, $price, $product_id);
    if ($stmt->execute()) {
        header('Location: products.php?edit_success_message=Product has been updated successfully');
    } else {
        header('Location: products.php?edit_failure_message=Error occurred, try again');
    }
    exit();
} else {
    header('Location: products.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <link rel="stylesheet" href="css/bootstrap.min.css.map">
    <link rel="stylesheet" href="adminstyle.css">
    <link rel="stylesheet" href="media.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        .container {
            max-width: 1000px;
            margin: auto;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>
    <div class="container">
        <h1 class="text-center">Edit Product</h1>
        <div class="card">
            <div class="card-header">
                Edit Product
            </div>
            <div class="card-body">
                <form id="edit-form" enctype="multipart/form-data" method="POST" action="edit_product.php">
                    <?php if (isset($_GET['error'])) { ?>
                        <p style="color: red;"><?php echo htmlspecialchars($_GET['error']); ?></p>
                    <?php } ?>
                    <?php if ($products) { foreach ($products as $product) { ?>
                        <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['product_id']); ?>"/>
                        <div class="form-group">
                            <label for="product_title">Product Name</label>
                            <input type="text" class="form-control" name="product_title" value="<?php echo htmlspecialchars($product['product_title']); ?>" id="product_title" placeholder="Enter product name">
                        </div>
                        <div class="form-group">
                            <label for="product_description">Description</label>
                            <input type="text" class="form-control" name="product_description" value="<?php echo htmlspecialchars($product['product_description']); ?>" id="product_description" placeholder="Enter product description">
                        </div>
                        <div class="form-group">
                            <label for="product_Size">Size</label>
                            <input type="text" class="form-control" name="product_Size" value="<?php echo htmlspecialchars($product['product_size']); ?>" id="product_Size" placeholder="Enter product size">
                        </div>
                        <div class="form-group">
                            <label for="product_Quantity">Quantity</label>
                            <input type="number" class="form-control" name="product_Quantity" value="<?php echo htmlspecialchars($product['product_quantity']); ?>" id="product_Quantity" placeholder="Enter product quantity">
                        </div>
                        <div class="form-group">
                            <label for="product_Color">Color</label>
                            <input type="text" class="form-control" name="product_Color" value="<?php echo htmlspecialchars($product['product_color']); ?>" id="product_Color" placeholder="Enter product color">
                        </div>
                        <div class="form-group">
                            <label for="product_Price">Price</label>
                            <input type="number" class="form-control" name="product_Price" value="<?php echo htmlspecialchars($product['product_price']); ?>" id="product_Price" placeholder="Enter product price">
                        </div>
                    <?php }} else { ?>
                        <p>No product found.</p>
                    <?php } ?>
                    <button type="submit" name="update_btn" class="btn btn-primary">Edit</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
