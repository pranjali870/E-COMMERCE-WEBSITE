<?php
$servername = "localhost";
$username = "root";
$password = ""; // Empty password if none is set
$database = "users"; // Make sure this database exists

// If using default MySQL port (3306), change to 3306
$conn = mysqli_connect($servername, $username, $password, $database, 3308);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>