<?php
include ('admin/_dbconnect.php');
include ('function/function_connect.php');

// Check if product_id is set in the URL
if(isset($_GET['product_id'])) {
  // Get the product_id from the URL
  $product_id = $_GET['product_id'];
  
  // Fetch the product details from the database using the product_id
  $select_query = "SELECT * FROM `products` WHERE product_id = $product_id";
  $result_query = mysqli_query($conn, $select_query);
  
  // Check if the product exists
  if(mysqli_num_rows($result_query) > 0) {
      // Product exists, fetch its details
      $row = mysqli_fetch_assoc($result_query);
     
      $product_title = $row['product_title'];
      $product_category = $row['product_category'];
      $product_description = $row['product_description'];
      $product_image1 = $row['product_image1'];
      $product_image2 = $row['product_image2'];
      $product_image3 = $row['product_image3'];
      $product_image4 = $row['product_image4'];
      $product_price = $row['product_price'];
      $product_quantity= $row['product_quantity'];
      ?>
      <section class="singleproduct my-5 pt-3">
        <div class="row mt-7">
          <div class="col-lg-4 col-md-6 col-sm-12">
            <div id="zoom-container">  
              <img class="img-fluid w-96 h-80 pb-2 p-5" src="./admin/productimg/<?php echo $product_image1; ?>" id="mainimg"/>
            </div>
            <div class="small-img-group">
              <div class="small-img-col">
                <img src="./admin/productimg/<?php echo $product_image2; ?>" width="100" class="small-img">
              </div>
              <div class="small-img-col">
                <img src="./admin/productimg/<?php echo $product_image3; ?>" width="100" class="small-img">
              </div>
              <div class="small-img-col">
                <img src="./admin/productimg/<?php echo $product_image4; ?>" width="100" class="small-img">
              </div>
              <div class="small-img-col">
                <img src="./admin/productimg/<?php echo $product_image1; ?>" width="100" class="small-img">
              </div>
            </div>
          </div> 
          <div class="col-lg-5 col-md-12 col-12">
            <h3><?php echo $product_title; ?></h3>
            <h3 class="py-4"><?php echo $product_category; ?></h3>
            <h2><i class="fa-solid fa-indian-rupee-sign"></i><?php echo $product_price; ?></h2>
            <form method="post" action="./admin/cart.php">
              <input type="hidden" name="product_id" value="<?php echo $product_id; ?>"/>
              <input type="hidden" name="product_image1" value="<?php echo $product_image1; ?>"/>
              <input type="hidden" name="product_title" value="<?php echo $product_title; ?>"/>
              <input type="hidden" name="product_price" value="<?php echo $product_price; ?>"/>
              <input type="number" name="quantity" value="<?php echo $product_quantity; ?>"/>
              <button class="btn btn-primary" type="submit" name="add_to_cart">Add to Cart</button>
            </form>
            <h4 class="mt-5 mb-5">Product Details</h4>
            <span><?php echo $product_description; ?></span>
          </div>
        </div>
      </section>
      <?php
  } else {
    // Product not found
    echo "Product not found.";
  }
} else {
  // product_id not set in the URL
  echo "Product ID not provided.";
}
?>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- Zoom.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/zoom.js/2.4.2/zoom.min.js"></script>
<script>
  // Zoom functionality
  const mainImg = document.getElementById("mainimg");
  const smallImgs = document.querySelectorAll(".small-img");

  smallImgs.forEach(smallImg => {
    smallImg.addEventListener("click", () => {
      mainImg.src = smallImg.src;
    });
  });

  // Initialize zoom
  new Zoom(mainImg);
</script>
</body>
</html>
<?php
      echo"
      <section class ='singleproduct my-5 pt-3'>
    <div class='row mt-7'>
        <div class='col-lg-4 col-md-6 col-sm-12'>
          <div id='zoom-container'>  
            <img class='img-fluid w-96 h-80 pb-2 p-5 ' src='./admin/productimg/$product_image1'   id='mainimg'/>
            </div>
            <div class='small-img-group'>
                <div class='small-img-col'>
                    <img  src='./admin/productimg/$product_image2' width='100'class='small-img'>
                </div>
                <div class='small-img-col'>
                <img  src='./admin/productimg/$product_image3' width='100'class='small-img'>
            </div>
            <div class='small-img-col'>
            <img  src='./admin/productimg/$product_image4' width='100'class='small-img'>
        </div>
        <div class='small-img-col'>
            <img  src='./admin/productimg/$product_image1' width='100'class='small-img'>
        </div>
            </div>
        </div> 
        <div class='col-lg-5 col-md-12 col-12'>
        <h3>$product_title</h3>
        <h3 class='py-4'>$product_category</h3>
       <h2><i class='fa-solid fa-indian-rupee-sign'></i>$product_price'</h2>
       <form method='post' action='./admin/cart.php'>
                <input type='hidden' name='product_id' value='<?php echo $product_id; ?>'/>
                <input type='hidden' name='product_image1' value='<?php echo $product_image1; ?>'/>
                <input type='hidden' name='product_title' value='<?php echo $product_title; ?>'/>
                <input type='hidden' name='product_price' value='<?php echo $product_price; ?>'/>
                <input type='number' name='quantity' value='<?php echo $product_quantity;?>'/>
                <button class='btn btn-primary' type='submit' name='add_to_cart'>Add to Cart</button>
            </form>
      <h4 class='mt-5 mb-5'>Product Details</h4>
      <span>$product_description</span>
    </div>
</div>
</section>";

} else {
  // Product not found
  echo "Product not found.";
}
} else {
// product_id not set in the URL
echo "Product ID not provided.";
}

?>
<td>
    <div class="product-info">
    <img src="../admin/productimg/<?php echo $value['product_image1']; ?>" />
        <div>
            <p><?php echo $value['product_title'];?></p>
            <small><span>$</span><?php echo $value['product_price']?></small>
            <br>
            <from method = "POST" action ="cart.php">
              <input type="hidden" name="product_id"  value="<?php echo $value['product_id']?>"/>
            <input type="submit" name="remove_product" value="remove" class="remove-btn" />
</form>
        </div>
    </div>
  </td>
  <td> 
  <form method="POST" action="cart.php">
    <input type="hidden" name ="product_id" value ="<?php echo $value['product_id'];?>"/>
    <input type="number" value="<?php echo $value['product_quantity'];?>" name="product_quantity">
    <input type="submit" class="edit_btn" value="edit" name="edit_quantity"/>
  </form>
  </td>
  <td>
    <span>$</span>
    <span class="product-price">155</span>
    <br>
  </td>
  <table class="mt-5 pt-5">
  <tr>
  <th>Product</th>
  <th>Quantity</th>
  <th>Subtotal</th>
</tr>
<?php foreach($_SESSION['cart'] as $key => $value){?>

  <tr>
  <td>
    <div class="product-info">
    <img src="../admin/productimg/<?php echo $value['product_image1']; ?>" />
        <div>
            <p><?php echo $value['product_title'];?></p>
            <small><span>$</span><?php echo $value['product_price']?></small>
            <br>
            <from method = "POST" action ="cart.php">
              <input type="hidden" name="product_id"  value="<?php echo $value['product_id']?>"/>
              <input type="submit" name="remove_product" value="remove" class="remove-btn" />
      </form>
        </div>
    </div>
  </td>
  <td> 
  <input type="number" value="<?php echo $value['product_quantity'];?>" name="product_quantity">
    <a class="edit-btn" href="#">Edit</a>
  </td>
  <td>
    <span>$</span>
    <span class="product-price">155</span>
    <br>
  </td>
</tr>
<?php } ?>
</table>

<?php
session_start();
if(isset($_POST['add_to_cart'])){
  //if user has already added a product to cart
  if(isset($_SESSION['cart'])){
    $product_array_ids = array_column($_SESSION['cart'],"product_id");
    //if product has already added to cart or not
    if(!in_array($_POST['product_id'], $product_array_ids)){
   $product_id=$_POST ['product_id'];
      $product_array =array(
        'product_id'=>$_POST['product_id'],
        'product_title'=>$_POST['product_title'],
        'product_price'=>$_POST['product_price'],
        'product_image1'=>$_POST['product_image1'],
       'product_quantity'=>$_POST['product_quantity'],             
      );
      $_SESSION['cart'][$_POST['product_id']] = $product_array;
    //product has already been added
  }else{
        echo '<script>alert("product was already to cart");</script>';

  }
     //if this is the first product
}else{
    $product_id= $_POST['product_id'];
    $product_title =$_POST['product_title'];
    $product_price=$_POST['product_price'];
    $product_image1 =$_POST['product_image1'];
    $product_quantity =$_POST['product_quantity'];
    
    $product_array =array(
      'product_id'=>$product_id,
      'product_title'=>$product_title,
      'product_price'=>$product_price,
      'product_image1'=>$product_image1,
     'product_quantity'=>$product_quantity,
    );
    $_SESSION['cart'][$product_id]=$product_array;
}
  
  //remove product from cart
  }else if(isset($_POST['remove_product'])){
  $product_id = $_POST['product_id'];
  unset($_SESSION['cart'][$product_id]);
  }
  else if(isset($_post['edit_quantity'])){
 $product_id = $_POST['product_id'];
 $product_quantity = $_POST['$product_id'];
 $product_array= $_SESSION['cart']['product_id'];
 $product_array['product_quantity'] = $product_quantity;
 $_SESSION['cart'][$product_Id]=$product_array;
  
}else{
  header('location: index.php');
}
?>

<?php
session_start();

if (isset($_POST['add_to_cart'])) {
    // Get product details from the form
    $product_id = $_POST['product_id'];
    $product_array = array(
        'product_id' => $product_id,
        'product_title' => $_POST['product_title'],
        'product_price' => $_POST['product_price'],
        'product_image1' => $_POST['product_image1'],
        'product_quantity' => $_POST['product_quantity'],
    );

    // Check if cart session exists
    if (isset($_SESSION['cart'])) {
        // If product already exists in cart, update its quantity
        if (array_key_exists($product_id, $_SESSION['cart'])) {
            $_SESSION['cart'][$product_id]['product_quantity'] += $product_array['product_quantity'];
        } else {
            // If product does not exist in cart, add it
            $_SESSION['cart'][$product_id] = $product_array;
        }
    } else {
        // If cart session does not exist, create it and add product
        $_SESSION['cart'] = array($product_id => $product_array);
    }

    // Redirect back to the product page
    header('Location: ' . $_SERVER['HTTP_REFERER']);
    exit;
    calculateTotalCart();
} else if (isset($_POST['remove_product'])) {
    // Handle removing a product from the cart
    $product_id = $_POST['product_id'];
    if (isset($_SESSION['cart'][$product_id])) {
        unset($_SESSION['cart'][$product_id]);
    }

    // Redirect back to the cart page or any other appropriate action
    header('Location: cart.php');
    exit;
} else if (isset($_GET['edit_quantity'])) {
    // Handle editing the quantity of a product in the cart
    $product_id = $_GET['product_id'];
    $product_quantity = $_GET['product_quantity'];
    if ($product_quantity > 0) {
        $_SESSION['cart'][$product_id]['product_quantity'] = $product_quantity;
    } else {
        // Remove the product if the quantity is 0 or less
        unset($_SESSION['cart'][$product_id]);
    }

    // Redirect back to the cart page or any other appropriate action
    header('Location: cart.php');
    exit;
} else {
    // If the form was not submitted properly or no action was specified, redirect to home page or other appropriate action
    header('Location: index.php');
    exit;
}
function calculateTotalCart(){
  $total = 0;
  foreach($_SESSION['cart'] as $key => $value){
    $product = $_SESSION['cart'][$key];
    $price = $product['product_price'];
    $quantity = $product['product_quantity'];
    $total = $total+($price*$quantity);
  }
  $_SESSION['total'] = $total;
}
?>