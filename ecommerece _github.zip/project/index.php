<?php
include('layout/header.php');
include ('function/function_connect.php');
?>
<!--home-->
<section id="home" class="home">
<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
</div>
  <div class="carousel-inner">
    <div class="carousel-item active">
    <div class="page1" class="d-block w-100 img-fluid" ;>
      <div class="home-text">
        <h1>Women</h1>
      <h2>52% Discount For This Season</h2>
      <a href="register.php" class="btn btn-danger text-uppercase mt-4">Register</a>
      </div>
    </div>
 </div>
    <div class="carousel-item">
    <div class="page2">
      <div class="home-text"><h1>NEW STYLIST</h1>
    <h2> Fashion collection</h2>
      <a href="#" class="btn btn-danger text-uppercase mt-4">sale %</a>
    </div>
    </div>
</div>
<div class="carousel-item">
    <div class="page3">
      <div class="home-text"><h1>NEW STYLIST</h1>
    <h2> Fashion collection</h2>
      <a href="#" class="btn btn-danger text-uppercase mt-4"> 50% sale</a>
    </div>
    </div>
</div>
</div>
 <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true">
      <span class="ti-angle-left-slider-icon"></span>
    </span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true">
    <span class="ti-angle-right-slider-icon"></span>
  </span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>
<!--special product-->
<div class="title text-center">
   <h2 class="mb-4">Special Category Products</h2>
   <div>
        <div class="row">
            <div class="col-md-4 mb-2">
                <div class="card">
                    <img src="../project/img/dress.webp" class="card-img-top" alt="Product 1">
                    <div class="card-body">
                        <h5 class="card-title">WESTEN</h5>
                    </div>
                </div>
             </diV>
            <div class="col-md-4 mb-2">
                <div class="card">
                    <img src="../project/img/saree.webp" class="card-img-top" alt="Product 2">
                    <div class="card-body">
                        <h5 class="card-title">SAREE</h5>
                        <p class="card-text"></p>
                    </div>
                </div>
               </div>
                        <div class="col-md-4 mb-2">
                <div class="card">
                    <img src="../project/img/anarkali.jpg" class="card-img-top" alt="Product 2">
                    <div class="card-body">
                        <h5 class="card-title">INDIAN DRESS</h5>
                        <p class="card-text"></p>
                    </div>
                </div>
            </div>
        </div>
  <!--product-->
  <div class="title text-center">
        <h2 class="positin-relative d-inline-block mt-3 mb-4"> collection</h2>
</div>

<div class="row">
  <?php
  //call function
  //getproducts();
  while ($row = $featured_products->fetch_assoc()) { ?>
    <div class="col-md-4">
      <div class="product">
        <img src="./admin/productimg/<?php echo $row['product_image1']; ?>" alt="pic">
        <h4 class="p-name"><?php echo $row['product_title']; ?></h4>
        <p>Casual cloths with a modern fit, available in various colors, perfect for everyday wear.
</p>
        <h5 class="p_price"><i class="fa-solid fa-indian-rupee-sign"></i><?php echo $row['product_price']; ?></h5>
        <a href="single.php?product_id=<?php echo $row['product_id']; ?>"><button class="btn btn-primary">VIEW MORE</button></a>

      </div>
    </div>
  <?php } ?>
</div>

  
<?php include('layout/footer.php'); ?>
</body>
</html>