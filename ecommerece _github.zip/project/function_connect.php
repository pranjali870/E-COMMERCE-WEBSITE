<?php
include ('_dbconnect.php');
//getting product
$stmt = $conn->prepare("SELECT *FROM products  ORDER BY RAND() LIMIT 9");
$stmt->execute();
$featured_products = $stmt->get_result();

function getSlugActive($stmt, $product_id) {
  global $conn; // Assuming $conn is your database connection
  // Using prepared statement to prevent SQL injection
  $query = "SELECT * FROM $stmt WHERE product_id = ? LIMIT 1";
  $stmt = $conn->prepare($query);
  $stmt->bind_param("s", $product_id); // Assuming product_category is of type string
  $stmt->execute();
  $result = $stmt->get_result();

  // Fetching the single row directly
  if ($result->num_rows == 1) {
      return $result->fetch_assoc();
  } else {
      return null; // No matching row found
  }
}

?>
