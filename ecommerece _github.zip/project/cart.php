<?php
include('layout/header.php');

session_start();

// Function to calculate subtotal of the cart
function calculateSubtotal() {
    $subtotal = 0;
    if(isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $product) {
            // Ensure product_price and product_quantity are numeric before performing arithmetic operations
            $subtotal += (float)$product['product_price'] * (int)$product['product_quantity'];
        }
    }
    $_SESSION['calculateSubtotal'] = $subtotal;
    return $subtotal;

}

// Function to calculate total of the cart (you can expand this for taxes, shipping, etc.)
function calculateTotal() {
    return calculateSubtotal();
}
// Function to add product to cart
if (isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];
    $product_array = array(
        'product_id' => $product_id,
        'product_title' => $_POST['product_title'],
        'product_price' => $_POST['product_price'],
        'product_image1' => $_POST['product_image1'],
        'product_quantity' => $_POST['product_quantity'],
    );

    if (isset($_SESSION['cart'])) {
        if (array_key_exists($product_id, $_SESSION['cart'])) {
            // Product already exists in the cart, show a message
            echo "<script>alert('product is already add in to cart')</script>";
            exit;
        } else {
            $_SESSION['cart'][$product_id] = $product_array;
        }
    } else {
        $_SESSION['cart'] = array($product_id => $product_array);
    }

    // Redirect back to the product page after adding to cart
    header('Location: cart.php');
    exit;
}
// Function to remove product from cart
if (isset($_POST['remove_product'])) {
    $product_id = $_POST['product_id'];
    if (isset($_SESSION['cart'][$product_id])) {
        unset($_SESSION['cart'][$product_id]);
    }
    header('Location: cart.php');
    exit;
}

// Function to edit quantity of product in cart
if (isset($_POST['edit_quantity'])) {
    $product_id = $_POST['product_id'];
    $product_quantity = $_POST['product_quantity'];
    if ($product_quantity > 0) {
        $_SESSION['cart'][$product_id]['product_quantity'] = $product_quantity;
    } else {
        unset($_SESSION['cart'][$product_id]);
    }
    calculateTotal();
    header('Location: cart.php');
    exit;
}

?>

<body>
<section class="cart container my-5 py-5">
  <div class="container mt-5">
    <h2 class="font-weight-bolde">Your Cart</h2>
    <hr>
</div>
<table class="mt-5 pt-5">
    <tr>
        <th>Product</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Subtotal</th>
        <th>Action</th>
    </tr>
    <?php if(isset($_SESSION['cart']) && !empty($_SESSION['cart'])) { ?>
            <?php foreach ($_SESSION['cart'] as $key => $value) { ?>
                <tr>
            <td>
                <div class="product-info">
                    <img src="./admin/productimg/<?php echo isset($value['product_image1']) ? $value['product_image1'] : ''; ?>" />
                    <div>
                        <p><?php echo isset($value['product_title']) ? $value['product_title'] : ''; ?></p>
                        <small><span><i class="fa-solid fa-indian-rupee-sign"></i></span><?php echo isset($value['product_price']) ? $value['product_price'] : ''; ?></small>
                        <br>
                        <form method="POST" action="cart.php">
                            <input type="hidden" name="product_id" value="<?php echo isset($value['product_id']) ? $value['product_id'] : ''; ?>"/>
                        </form>
                    </div>
                </div>
            </td>
            <td>
                <form method="POST" action="cart.php">
                    <input type="hidden" name="product_id" value="<?php echo isset($value['product_id']) ? $value['product_id'] : ''; ?>"/>
                    <input type="number" name="product_quantity" value="<?php echo isset($value['product_quantity']) ? $value['product_quantity'] : ''; ?>" min="1" max="10" />
                    <input type="hidden" name="edit_quantity" value="1"/>
                    <input type="submit" value="Edit" />
                </form>
            </td>
            <td><i class="fa-solid fa-indian-rupee-sign"></i><?php echo isset($value['product_price']) ? $value['product_price'] : ''; ?></td>
            <td><i class="fa-solid fa-indian-rupee-sign"></i><?php echo isset($value['product_price']) && isset($value['product_quantity']) ? ($value['product_price'] * $value['product_quantity']) : ''; ?></td>
            <td>
                <form method="POST" action="cart.php">
                    <input type="hidden" name="product_id" value="<?php echo isset($value['product_id']) ? $value['product_id'] : ''; ?>"/>
                    <input type="submit" value="Remove" name="remove_product"/>
                </form>
            </td>
        </tr>
    <?php } 
    }?>
    <tr>
        <td colspan="3">Subtotal</td>
        <td><i class="fa-solid fa-indian-rupee-sign"></i><?php echo calculateSubtotal(); ?></td>
    </tr>
    <tr>
        <td colspan="3">Total</td>
        <td><i class="fa-solid fa-indian-rupee-sign"></i><?php echo calculateTotal(); ?></td>
    </tr>
    </table>
        <div class="checkout-container">
          <form method="POST" action ="checkout.php">
  <input  class="btn checkout-btn" value="Checkout" name="checkout">
  </form>
</div>
    </section>
</body>
</html>