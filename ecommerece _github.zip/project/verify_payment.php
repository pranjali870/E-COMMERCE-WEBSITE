<?php

require('config.php');

session_start();

require('razorpay-php/Razorpay.php');
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

$success = true;
include('gateway-config.php');


$error = "Payment Failed";

if (empty($_POST['razorpay_payment_id']) === false)
{
    $api = new Api($keyId, $keySecret);

    try
    {
        // Please note that the razorpay order ID must
        // come from a trusted source (session here, but
        // could be database or something else)
        $attributes = array(
            'razorpay_order_id' => $_SESSION['razorpay_order_id'],
            'razorpay_payment_id' => $_POST['razorpay_payment_id'],
            'razorpay_signature' => $_POST['razorpay_signature']
        );

        $api->utility->verifyPaymentSignature($attributes);
    }
    catch(SignatureVerificationError $e)
    {
        $success = false;
        $error = 'Razorpay Error : ' . $e->getMessage();
    }
}

if ($success === true)
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $city = $_POST['city'];
    $address = $_POST['address'];
    $order_cost = $_SESSION['calculateSubtotal'];
    $order_status ="not paid";
    $user_id = $_SESSION['user_id'];
    $order_date = date('y-m-d H:i:s');
    $posted_has=$_SESSION['razorpay_order_id'];
    if(isset($_POST['razorpay_payment_id'])){
        $tcv=$_POST['razorpay_payment_id'];
        $order_cost=$_SESSION['calculateSubtota'];
        $order_status="paid";
        $subject='your payment has been successful';
        $key_value="okpmt";
        $sql ="SELECT count(*) from payments WHERE tcv=:tcv";
        $stmt =$db->prepare($sql);
        $stmt->bindParam(':tcv',$tcv, PDO::PARAM_STR);
        $stmt->execute();
        $countts=$stmt->fetchcolumn();
        if($tcv!=''){
            if($countts<=0){
                $sql="INSERT INTO payments(payment_id, order_id, user_id, transaction_id, payment_date)VALUES(:payment_id, :order_id, :user_id, :transaction_id, :payment_date)";
                $stmt = $db->prepare($sql);
                $stmt->bindParam(':payment_id',$payment_id,PDO::PARAM_STR);
                $stmt->bindParam(':order_id',$order_id,PDO::PARAM_STR);
                $stmt->bindParam(':user_id',$user_id,PDO::PARAM_STR);
                $stmt->bindParam(':transaction_id',$transaction_id,PDO::PARAM_STR);
                $stmt->bindParam(':payment_date',$payment_date,PDO::PARAM_STR);
                $stmt->execute();
                
            
            }
            echo'<h2 style ="color:#33FF00";>'.$subject.'</h2>;
            echo '<table class="table">';
            echo'<tr>';
            $rows =$sql ="SELECT * from payments WHERE tcv=:tcv";
            $stmt = $db->prepare($sql);
            $stmt->bindParam(':tcv',$tcv,PDO::PARAM_STR);
            $stmt->execute();
            $rows=$stmt->fetchAll();
            foreach($rows as $row)
            {
               $dbdate =$row['payment_date'];

        }
    } $stmt = $con->prepare("UPDATE orders SET order_status = ? WHERE order_id = ?");
    $stmt->bind_param('si', $order_status, $order_id);
    $stmt->execute();
}
else
{
    $html = "<p>Your payment failed</p>
             <p>{$error}</p>";
}

echo $html;
