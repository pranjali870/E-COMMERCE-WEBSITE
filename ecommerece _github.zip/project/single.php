<?php
include('layout/header.php');
include ('admin/_dbconnect.php');
include ('function/function_connect.php');

// Check if product_id is set in the URL
if(isset($_GET['product_id'])) {
  // Get the product_id from the URL
  $product_id = $_GET['product_id'];
  
  // Fetch the product details from the database using the product_id
  $select_query = "SELECT * FROM `products` WHERE product_id = $product_id";
  $result_query = mysqli_query($conn, $select_query);
  
  // Check if the product exists
  if(mysqli_num_rows($result_query) > 0) {
      // Product exists, fetch its details
      $row = mysqli_fetch_assoc($result_query);
     
      $product_title = $row['product_title'];
      $product_category = $row['product_category'];
      $product_description = $row['product_description'];
      $product_image1 = $row['product_image1'];
      $product_image2 = $row['product_image2'];
      $product_image3 = $row['product_image3'];
      $product_image4 = $row['product_image4'];
      $product_price = $row['product_price'];
      $product_quantity= $row['product_quantity'];?>
    
      <section class="singleproduct my-5 pt-3">
        <div class="row mt-7">
          <div class="col-lg-4 col-md-6 col-sm-12">
            <div id="zoom-container">  
              <img class="img-fluid w-96 h-80 pb-2 p-5" src="./admin/productimg/<?php echo $product_image1; ?>" id="mainimg"/>
            </div>
            <div class="small-img-group">
              <div class="small-img-col">
                <img src="./admin/productimg/<?php echo $product_image2; ?>" width="100" class="small-img">
              </div>
              <div class="small-img-col">
                <img src="./admin/productimg/<?php echo $product_image3; ?>" width="100" class="small-img">
              </div>
              <div class="small-img-col">
                <img src="./admin/productimg/<?php echo $product_image4; ?>" width="100" class="small-img">
              </div>
              <div class="small-img-col">
                <img src="./admin/productimg/<?php echo $product_image1; ?>" width="100" class="small-img">
              </div>
            </div>
          </div> 
          <div class="col-lg-5 col-md-12 col-12">
            <h3><?php echo $product_title; ?></h3>
            <h3 class="py-4"><?php echo $product_category; ?></h3>
            <h2><i><i class="fa-solid fa-indian-rupee-sign"></i></i><?php echo $product_price; ?></h2>
            <form method="POST" action ="cart.php">
    <input type="hidden" name="product_id" value="<?php echo $product_id; ?>"/>
    <input type="hidden" name="product_image1" value="<?php echo $product_image1; ?>"/>
    <input type="hidden" name="product_title" value="<?php echo $product_title; ?>"/>
    <input type="hidden" name="product_price" value="<?php echo $product_price; ?>"/>
    <input type="hidden" name="product_quantity" value="<?php echo $product_quantity; ?>"/>
    <input type="submit" name="add_to_cart" value="add cart" class="btn btn-primary">
    </form>
            <h4 class="mt-5 mb-5">Product Details</h4>
            <span><?php echo $product_description; ?></span>
          </div>
        </div>
      </section>
      <?php
  } else {
    // Product not found
    echo "Product not found.";
  }
} else {
  // product_id not set in the URL
  echo "Product ID not provided.";
}
?>

<!-- jquery-->
<script src="js/jquery-3.7.1.js"></script>
<!--bootstrap js-->
<!-- <script src=" js/bootstrap.bundle.min.js"></script>-->
<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>-->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.s" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
<script src="zoom.js"></script>
<!--custom js-->
<script>
 var mainImg = document.getElementById("mainimg");
 var smallimg = document.getElementsByClassName("small-img");
for( let i=0;i<4;i++){
    smallimg[i].onclick = function(){
    mainImg.src = smallimg[i].src;
   }
}
//zoom
const image = document.getElementById('mainimg');

  image.addEventListener('mouseenter', () => {
    image.classList.add('zoomed');
  });

  image.addEventListener('mouseleave', () => {
    image.classList.remove('zoomed');
  });
</script>
</body>
</html>
