<?php
session_start();

require 'razorpay-php-2.9.0/Razorpay.php'; // Include Razorpay library
require 'gateway-config.php';
include '_dbconnect.php'; // Ensure this file contains your $con MySQLi connection setup

use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

$success = true;
$error = "Payment Failed";

// Check if necessary session variables are set
if (!isset($_SESSION['razorpay_order_id'], $_SESSION['order_id'], $_SESSION['user_id'])) {
    $success = false;
    $error = 'Session variables are missing.';
}

// Verify if payment ID and signature are present
if ($success && (!isset($_POST['razorpay_payment_id']) || !isset($_POST['razorpay_signature']))) {
    $success = false;
    if (empty($_POST['razorpay_payment_id'])) {
        $error = 'razorpay_payment_id is missing.';
    } elseif (empty($_POST['razorpay_signature'])) {
        $error = 'razorpay_signature is missing.';
    }
}

if ($success === true) {
    $api = new Api($keyId, $keySecret);

    try {
        // Verify the payment signature
        $attributes = array(
            'razorpay_order_id' => $_POST['razorpay_order_id'],
            'razorpay_payment_id' => $_POST['razorpay_payment_id'],
            'razorpay_signature' => $_POST['razorpay_signature']
        );

        $api->utility->verifyPaymentSignature($attributes);
    } catch (SignatureVerificationError $e) {
        $success = false;
        $error = 'Razorpay Error: ' . $e->getMessage();
    }
}

if ($success === true) {
    $order_id = $_SESSION['order_id'];
    $user_id = $_SESSION['user_id'];
    $transaction_id = $_POST['razorpay_payment_id'];
    $payment_date = date('Y-m-d H:i:s'); // Correct date format
    $order_status = "paid";

    // Ensure the MySQLi connection is available
    if ($conn) {
        // Insert the payment details into the database
        $stmt = $conn->prepare("INSERT INTO payments (order_id, user_id, transaction_id, payment_date) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('iiss', $order_id, $user_id, $transaction_id, $payment_date);
        if ($stmt->execute()) {
            // Update the order status in the orders table
            $stmt = $conn->prepare("UPDATE orders SET order_status = ? WHERE order_id = ?");
            $stmt->bind_param('si', $order_status, $order_id);
            if ($stmt->execute()) {
                // Display success message
                echo '<h2 style="color:#33FF00;">Your payment has been successful</h2>';
            } else {
                echo '<h2 style="color:#FF0000;">Failed to update order status: ' . $stmt->error . '</h2>';
            }
        } else {
            echo '<h2 style="color:#FF0000;">Failed to insert payment details: ' . $stmt->error . '</h2>';
        }
        $stmt->close();
    } else {
        echo '<h2 style="color:#FF0000;">Database connection error</h2>';
    }
} else {
    echo "<p>Your payment failed</p><p>{$error}</p>";
}
?>
