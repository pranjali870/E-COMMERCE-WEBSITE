<?php
include ('admin/_dbconnect.php');
include ('function/function_connect.php');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="x-UA-Compatiable" content="IE=edge">
    <meta name="viewport" content="width=device-width", initial-scale="1.0">
    <title>project</title>
    <!--bootstrap css-->
    <link rel="stylesheet" href="css/bootstrap.min.css.map">
    <!--font awesome icons-->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <!--font-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@800&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="media.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
</head>
<body>
<nav class="navbar navbar-expand-lg fixed-top fs-4 bg-body-tertiary">
  <div class="container-fluid">
  <img src="../project/img/logo.jpg" alt="logo" class="logo">
    <a class="navbar-brand" href="#"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarScroll">
      <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Product</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Login</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            About us
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">link 1</a></li>
            <li><a class="dropdown-item" href="#">link 2</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">link 3</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link " aria-disabled="true">Contact</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " aria-disabled="true"><i class="fa-solid fa-cart-shopping"></i>cart</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " aria-disabled="true">Total price:</a>
      </li>
     </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="" aria-label="Search">
        <button class="btn btn-outline-primary rounded-pill" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
<section class ="singleproduct my-5 pt-3">
    <div class="row mt-7">
        <div class="col-lg-4 col-md-6 col-sm-12">
            <img class="img-fluid w-96 h-80 pb-2 p-5 " src="./admin/productimg/$product_image1'"  id="mainimg"/>
            <div class="small-img-group">
                <div class="small-img-col">
                    <img  src="./admin/productimg/$product_image2'" width="100"class="small-img">
                </div>
                <div class="small-img-col">
                    <img  src="./admin/productimg/$product_image3'" width="100"class="small-img">
                </div>
                <div class="small-img-col">
                    <img  src="./admin/productimg/$product_image4'" width="100"class="small-img">
                </div>
                <div class="small-img-col">
                  <img  src="./admin/productimg/$product_image1'" width="100"class="small-img">
              </div>
            </div>
        </div> 
           <div class="col-lg-5 col-md-12 col-12">
            <h3>WESTEN DRESS</h3>
            <h3 class="py-4">Maxi Gathered Cami Dress</h3>
           <h2><i class="fa-solid fa-indian-rupee-sign"></i>  800</h2>
          <input type="number" value="1">
          <button class="btn btn-primary">ADD TO CART</button> 
         <h4 class="mt-5 mb-5">Product Details</h4>
          <span> Material: Polyester<br>Stretchability: Very Stretchable<br>Fit: Slim Fit<br> Quantity: 1 Piece
            Chest Pad: No<br>Belt: No <br> Neckline: Spaghetti Strap<br> Sleeve Type: Sleeveless
           <br> Sleeve Length: Sleeveless<br> Length: Maxi
           <br> Silhouette: S-line</span>
        </div>
    </div>
</section>
<!--collection-->
<div class="title text-center">
  <h2 class="positin-relative d-inline-block mt-3 mb-4"> collection</h2>
  <div class="row">
    <div class=col-md-4>
    <div class="product">
      <img src="../project/img/anarkali1.1.webp" alt="pic">
      <h4>Gathered Bodycon Dress</h4>
      <p>A gathered mesh dress with a square neckline and long sleeves. The pencil-shaped hem adds a touch of elegance .</p>
      <h5><i class="fa-solid fa-indian-rupee-sign"></i>1200.00</h5>
      <button class="btn btn-primary">ADD TO CARD</button>
      <button class="btn btn-primary">VIEW MORE</button>
     </div>
   </div>
   <div class=col-md-4>
    <div class="product">
      <img src="../project/img/anarkali.webp" alt="pic">
      <h4>Ruffle Detail Fishtail Dress</h4>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur vitae quis voluptatem!</p>
      <h5><i class="fa-solid fa-indian-rupee-sign"></i>2000.00</h5>
      <button class="btn btn-primary">ADD TO CARD</button>
      <button class="btn btn-primary">VIEW MORE</button>
     </div>
     </div>
     <div class="col-md-4">
      <div class="product">
        <img src="../project/img/anarkali3.2.webp" alt="pic">
        <h4>Draped A-Line Dress</h4>
        <p>Long A-line cami dress with a flared hem and a draped, lace-up design detail. Sleeveless with a spaghetti strap neckline.</p>
        <h5><i class="fa-solid fa-indian-rupee-sign"></i>800.00</h5>
        <button class="btn btn-primary">ADD TO CARD</button>
        <button class="btn btn-primary">VIEW MORE</button>
       </div>
  </div>
</div>
</div>

<!-- jquery-->
<script src="js/jquery-3.7.1.js"></script>
<!--bootstrap js-->
<!-- <script src=" js/bootstrap.bundle.min.js"></script>-->
<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>-->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
<!--custom js-->
<script>
 var mainImg = document.getElementById("mainimg");
 var smallimg = document.getElementsByClassName("small-img");
for( let i=0;i<4;i++){
    smallimg[i].onclick = function(){
    mainImg.src = smallimg[i].src;
   }
}
//zoom
const image = document.getElementById('mainimg');

  image.addEventListener('mouseenter', () => {
    image.classList.add('zoomed');
  });

  image.addEventListener('mouseleave', () => {
    image.classList.remove('zoomed');
  });

</script>
</body>
</html>
