<?php
session_start();

// Include Razorpay and database configuration
require 'razorpay-php-2.9.0/Razorpay.php';
require('gateway-config.php');
include('_dbconnect.php'); // Ensure this file contains your $con MySQLi connection setup

use Razorpay\Api\Api;

$api = new Api($keyId, $keySecret);

// Retrieve the order ID and amount from the POST request or session
if (!isset($_POST['amount'])) {
    echo "Amount is not set";
    exit();
}

$amount = $_POST['amount'];
$order_id = $_POST['order_id'];

// Debug: Ensure order_id and amount are set
if (!isset($amount, $order_id)) {
    echo "Order ID or Amount is missing";
    exit();
}

// Create an order on Razorpay
try {
    $razorpayOrder = $api->order->create(array(
        'receipt' => $order_id,
        'amount' => $amount * 100, // Amount in paise
        'currency' => 'INR',
        'payment_capture' => 1 // Auto capture
    ));
    
    $razorpayOrderId = $razorpayOrder['id'];
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
    exit();
}

// Pass the order details to the front end
$_SESSION['razorpay_order_id'] = $razorpayOrderId;
$_SESSION['amount'] = $amount;
$_SESSION['order_id'] = $order_id;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2JlPb5Xx6l9R8Po4gycWE3kwok9zcO+pgSx3Xxs3XB1rFN7B5y5t" crossorigin="anonymous">
</head>
<body>
    <div class="container text-center mt-5">
        <h2 class="font-weight-bold">Complete your payment</h2>
        <hr class="mx-auto">
        <p>Total payment: ₹<?php echo htmlspecialchars($amount); ?></p>
        <button id="rzp-button1" class="btn btn-primary">Pay Now</button>
    </div>

    <!-- Include Razorpay Checkout script -->
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script>
        var options = {
            "key": "<?php echo $keyId; ?>", // Enter the Key ID generated from the Dashboard
            "amount": "<?php echo $amount * 100; ?>", // Amount is in currency subunits. Default currency is INR. Hence, it should be in paise
            "currency": "INR",
            "name": "Your Company Name",
            "description": "Test Transaction",
            "image": "https://your-logo-url.com/logo.png", // Optional
            "order_id": "<?php echo $razorpayOrderId; ?>", // This is the order_id created in the previous step
            "handler": function (response){
                // Send the payment response to the server for verification
                var form = document.createElement('form');
                form.method = 'POST';
                form.action = 'payment_success.php';

                var razorpayPaymentId = document.createElement('input');
                razorpayPaymentId.type = 'hidden';
                razorpayPaymentId.name = 'razorpay_payment_id';
                razorpayPaymentId.value = response.razorpay_payment_id;
                form.appendChild(razorpayPaymentId);

                var razorpayOrderId = document.createElement('input');
                razorpayOrderId.type = 'hidden';
                razorpayOrderId.name = 'razorpay_order_id';
                razorpayOrderId.value = response.razorpay_order_id;
                form.appendChild(razorpayOrderId);

                var razorpaySignature = document.createElement('input');
                razorpaySignature.type = 'hidden';
                razorpaySignature.name = 'razorpay_signature';
                razorpaySignature.value = response.razorpay_signature;
                form.appendChild(razorpaySignature);

                document.body.appendChild(form);
                form.submit();
            },
            "prefill": {
                "name": "fashion mart",
                "email": "your-email@example.com",
                "contact": "Your Phone Number"
            },
            "theme": {
                "color": "#3399cc"
            }
        };

        var rzp1 = new Razorpay(options);
        document.getElementById('rzp-button1').onclick = function(e){
            rzp1.open();
            e.preventDefault();
        }
    </script>
</body>
</html>
