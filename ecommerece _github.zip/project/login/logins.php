<?php
$showAlert = false;
include ('_dbconnect.php');if($_SERVER["REQUEST_METHOD"]=="POST"){

$username = $_POST["username"];
$password = $_POST["password"];
$cpassword =$_POST["cpassword"];
$exists=false;
if(($password == $cpassword) && $exists ==false){
$sql= "INSERT INTO `users` ( `username`, `password`, `dt`) VALUES ('$username', '$password',current_timestamp())";
  $result =mysqli_query($conn, $sql);
  if($result){
    $showAlert =true;
  }
}
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="x-UA-Compatiable" content="IE=edge">
    <meta name="viewport" content="width=device-width", initial-scale="1.0">
    <title>project</title>
    <!--bootstrap css-->
    <link rel="stylesheet" href="css/bootstrap.min.css.map">
    <!--font awesome icons-->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <!--font-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@800&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="media.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    
</head>
<body>
<nav class="navbar navbar-expand-lg fixed-top fs-4 bg-body-tertiary">
  <div class="container-fluid">
  <img src="../project/img/logo.jpg" alt="logo" class="logo">
    <a class="navbar-brand" href="#"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarScroll">
      <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Product</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Login</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            About us
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">link 1</a></li>
            <li><a class="dropdown-item" href="#">link 2</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">link 3</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link " aria-disabled="true">Contact</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " aria-disabled="true"><i class="fa-solid fa-cart-shopping"></i>cart</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " aria-disabled="true">Total price:</a>
      </li>
     </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="" aria-label="Search">
        <button class="btn btn-outline-primary rounded-pill" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
<?php 
if($showAlert){
  echo' <div class="alert alert-success my-5" role="alert">
  Your accouunt is now created and you can login
  </div>';
}
?>
<div class="containers my-2">
     <h1 class="text-center">Signup to our website</h1>
     <form action="../project/login.php" method="post">
        <div class="form-group col-md-5">
            <label for="username">Username</label>
            <input type="text" class="form-control" id="username" name="username" aria-describedby="emailHelp">
            
        </div>
        <div class="form-group col-md-5">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password">
        </div>
        <div class="form-group col-md-5">
            <label for="cpassword">Confirm Password</label>
            <input type="password" class="form-control" id="cpassword" name="cpassword">
            <small id="emailHelp" class="form-text text-muted">Make sure to type the same password</small>
        </div>
        <button type="submit" class="btn btn-primary">SignUp</button>
     </form>
    </div>
</body>
<script src="js/jquery-3.7.1.js"></script>
   <!--bootstrap js-->
  <!-- <script src=" js/bootstrap.bundle.min.js"></script>-->
 <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
  integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>-->
 <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
   <!--custom js-->
   <script src=" "></script>
</body>
</html><?php
session_start();
if(isset($_POST['add_to_cart'])){
  //if user has already added a product to cart
  if(isset($_SESSION['cart'])){
    $product_array_ids = array_column($_SESSION['cart'],"product_id");
    //if product has already added to cart or not
    if(!in_array($_POST['product_id'], $product_array_ids)){

      $product_array =array(
        'product_id'=>$_POST['product_id'],
        'product_title'=>$_POST['product_title'],
        'product_price'=>$_POST['product_price'],
        'product_image1'=>$_POST['product_image1'],
       'product_quantity'=>$_POST['product_quantity'],
                    
      );
      $_SESSION['cart'][$_POST['product_id']] = $product_array;


  
    //product has already been added
  }else{
        echo '<script>alert("product was already to cart");</script>';

  }
     //if this is the first product
}else{
    $product_id= $_POST['product_id'];
    $product_title =$_POST['product_title'];
    $product_price=$_POST['product_price'];
    $product_image1 =$_POST['product_image1'];
    $product_quantity =$_POST['product_quantity'];
    
    $product_array =array(
      'product_id'=>$product_id,
      'product_title'=>$product_title,
      'product_price'=>$product_price,
      'product_image1'=>$product_image1,
     'product_quantity'=>$product_quantity,
    );
    $_SESSION['cart'][$product_id]=$product_array;

  }
}else{
  header('location: index.php');
}
?>