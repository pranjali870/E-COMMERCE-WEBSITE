<?php
session_start();
include ('..\admin\_dbconnect.php');
//if user has already registered then take user to account  page
if(isset($_SESSION['logged_in'])){
header('location: ../admin/account.php');
 exit;
}
if(isset($_POST['register'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmpassword = $_POST['confirmpassword'];

    if($password !== $confirmpassword){
        header('location: register.php?error=passwords dont match');
    } else if(strlen($password) < 6){
        header('location: register.php?error=Password must be at least 6 characters');
    } else {
      $stmt1 = $con->prepare("SELECT COUNT(*) FROM user WHERE user_email=?");
      $stmt1->bind_param('s', $email);
        $stmt1->execute();
        $stmt1->bind_result($num_rows);
        $stmt1->fetch();

        // Close the statement and free the result set
        $stmt1->close();

        if($num_rows != 0){
            header('location: register.php?error=user with this email already exists');
        } else {
            $stmt = $con->prepare("INSERT INTO user (user_name,user_email,user_password) VALUES(?,?,?)");
            $stmt->bind_param('sss', $name, $email, md5($password));

            if ($stmt->execute()){
              $user_id = $stmt->insert_id;
              $_SESSION['user_id'] = $user_id;
                $_SESSION['user_email'] = $email;
                $_SESSION['user_name'] = $name;
                $_SESSION['logged_in'] = true;
                header('location: ../admin/account.php?register_success=you registered successfully');
                exit; // Make sure to exit after redirection
            } else {
            header('location: register.php?error=could not create an acccount at the moment ');
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="x-UA-Compatiable" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1,shrink-to-fit=no">
    <title>signup</title>
    <!--bootstrap css-->
    <link rel="stylesheet" href="css/bootstrap.min.css.map">
    <!--font awesome icons-->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <!--font-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@800&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="media.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
</head>
<body>
<nav class="navbar navbar-expand-lg fixed-top fs-5 bg-body-tertiary">
  <div class="container-fluid">
  <img src="../project/img/logo1.jpg" alt=" " class="logo">
    <a class="navbar-brand" href="#"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarScroll">
      <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Product</a>
        </li>
        <li class="nav-item">
           <a class="nav-link" href="#">Login</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            About us
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">link 1</a></li>
            <li><a class="dropdown-item" href="#">link 2</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">link 3</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link " aria-disabled="true">Contact</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " aria-disabled="true"><i class="fa-solid fa-cart-shopping"></i>cart</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " aria-disabled="true">Total price:</a>
      </li>
     </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="" aria-label="Search">
        <button class="btn btn-outline-primary rounded-pill" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>

    <!--Register-->
    <section class="my-5 py-5">
          <div class="container text-center mt-3 pt-5">
            <h2 class="form-weight-bold">Register</h2>
            <hr class="mx-auto">
       </div> 
       
       <div class="mx-auto container">
        <form id="register-form" method ="POST" action ="register.php">
          <p style="color: red;"><?php if(isset($_GET['error'])){echo $_GET['error'];}?></p>
        <div class="form-group">
            <label>Name</label>
            <input type="text" class="form-control" id="register-name" name="name" placeholder="Name" required/>
          </div>

          <div class="form-group">
            <label>Email</label>
            <input type="text" class="form-control" id="register-email" name="email"  placeholder="Email" required/>
          </div>

          <div class="form-group">
            <label>Password</label>
            <input type="password" class="form-control" id="register-password" name="password"  placeholder="Password" required/>
          </div>

          <div class="form-group">
            <label>Confirm Password</label>
            <input type="password" class="form-control" id="register- confirm-password" name="confirmpassword"  placeholder="Confirm Password" required/>
          </div>


          <div class="form-group">
            <input type="submit" class="btn" id="register-btn"  name="register" value="Register"/>
          </div>

          <div class="form-group">
           <a id="login-url" class="btn">Do you have account? Login</a>
          </div>
        </form>
</section>
       <!-- jquery-->
   <script src="js/jquery-3.7.1.js"></script>
   <!--bootstrap js-->
  <!-- <script src=" js/bootstrap.bundle.min.js"></script>-->
 <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
  integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>-->
 <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
   <!--custom js-->
   <script src=" "></script>


</body>
</html>