<?php

include('layout/header.php');
include ('_dbconnect.php');

if(isset($_POST['order_details_btn']) && isset($_POST['order_id'])){
    $order_id = $_POST['order_id'];
    $order_status = $_POST['order_status'];

    $stmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
    $stmt->bind_param('i', $order_id);
    $stmt->execute();
    $order_details = $stmt->get_result();

    $total_order_price = calculateSubtotalOrderPrice($order_details);
} else {
   header('location: account.php');
   exit;
}
function calculateSubtotalOrderPrice($order_details) {
    $subtotal = 0;

    foreach($order_details as $row) { 
        $product_price = $row['product_price'];
        $product_quantity = $row['product_quantity'];
        $subtotal  = $subtotal +($product_price * $product_quantity);
    }
  
    return $subtotal;
}
?>

<!-- Orders details-->
<section id="orders" class="orders container my-5 py-3">
    <div class="container mt-5">
        <h2 class="font-weight-bold text-center">Order details</h2>
        <hr class="mx-auto">
    </div>

    <table class="mt-5 pt-5 mx-auto">
        <tr>
            <th>Product</th>
            <th>Price</th>
            <th>Quantity</th>
        </tr>
        <?php foreach( $order_details as $row) { ?>
            <tr>
                <td>
                    <div class="product-info">
                        <img src="./admin/productimg/<?php echo $row['product_image1'];?>"/> 
                        <div>
                            <p class="mt-3"><?php echo $row['product_name'];?></p>
                        </div>
                    </div> 
                </td>
                <td>
                    <span>$<?php echo $row['product_price'];?></span>
                </td>
                <td>
                    <span><?php echo $row['product_quantity'];?></span>
                </td>
            </tr>
        <?php } ?>
    </table>
 <?php if($order_status == "not paid"){?>
    <form  style="float: right;" method="POST" action="payment.php">
    <!-- Add hidden input fields for order status and subtotal -->
    <input type="hidden" name="order_id" value = "<?php  echo $order_id ;?>"/>
    <input type="hidden" name="total_order_price" value="<?php echo $total_order_price; ?>"/>
    <input type="hidden" name="order_status" value="<?php echo $order_status; ?>"/>
    <input type="submit" class="btn btn-primary" name="order_pay_btn" value="Pay Now"/>
</form>
<?php }?>
</section>

<!-- jquery-->
<script src="js/jquery-3.7.1.js"></script>
<!--bootstrap js-->
<!-- <script src=" js/bootstrap.bundle.min.js"></script>-->
<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>-->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
<!--custom js-->
<script src=" "></script>

</body>
</html>
