<?php
$server = "localhost"; // Define the hostname or IP address of your MySQL server
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$database = "users"; // Your MySQL database name

// Attempt to connect to MySQL database
$conn = mysqli_connect($server, $username, $password, $database, 3308);

echo "";
?>