<?php
include('layout/header.php');

include('_dbconnect.php');

// Initialize an empty array to store search results
$search_results = [];

// Check if the search query parameter is set
if (isset($_GET['search_data'])) {
    $search_data = mysqli_real_escape_string($conn, $_GET['search_data']); // Sanitize input

    // Query to search for products based on the search data
    $search_query = "SELECT * FROM products WHERE product_title LIKE '%$search_data%'";
    $result_query = mysqli_query($conn, $search_query);

    // Fetch search results
    while ($row = mysqli_fetch_assoc($result_query)) {
        $search_results[] = $row; // Add each row to the search results array
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop</title>
    <!-- Include your CSS and JavaScript files -->
</head>
<body>

<div class="title text-center">
        <h2 class="positin-relative d-inline-block mt-3 mb-4"> collection</h2>
</div>


    <!-- Display search results -->
    <?php if (!empty($search_results)) : ?>
        <div class="row text-center">
            <?php foreach ($search_results as $product) : ?>
                <div class="col-md-4">
                    <div class="product">
                        <img src="./admin/productimg/<?php echo $product['product_image1']; ?>" alt="pic">
                        <h4 class="p-name"><?php echo $product['product_title']; ?></h4>
                        <p><?php echo $product['product_description']; ?></p>
                        <h5 class="p_price"><?php echo $product['product_price']; ?></h5>
                        <a href="single.php?product_id=<?php echo $product['product_id']; ?>">
                            <button class="btn btn-primary">VIEW MORE</button>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Include your JavaScript files -->
</body>
</html>
