<?php
include('layout/header.php');
include ('function/function_connect.php');

?>
<div class="title text-center">
        <h2 class="positin-relative d-inline-block mt-8 mb-2"> collection</h2>
<div class="row">
  <?php
  //call function
  //getproducts
  
  while ($row = $featured_products->fetch_assoc()) { ?>
    <div class="col-md-4">
      <div class="product">
        <img src="./admin/productimg/<?php echo $row['product_image1']; ?>" alt="pic">
        <h4 class="p-name"><?php echo $row['product_title']; ?></h4>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur vitae quis voluptatem!</p>
        <h5 class="p_price"><i class="fa-solid fa-indian-rupee-sign"></i><?php echo $row['product_price']; ?></h5>
        <a href="single.php?product_id=<?php echo $row['product_id']; ?>"><button class="btn btn-primary">VIEW MORE</button></a>

      </div>
    </div>
  <?php } ?>
</div>

<!-- jquery-->
   <script src="js/jquery-3.7.1.js"></script>
   <!--bootstrap js-->
  <!-- <script src=" js/bootstrap.bundle.min.js"></script>-->
 <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
  integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>-->
 <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
   <!--custom js-->
   <script src=" "></script>
</body>
</html>