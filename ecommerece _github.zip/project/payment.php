<?php
require 'razorpay-php-2.9.0/Razorpay.php';// Using Composer's autoload for Razorpay
include('layout/header.php');
session_start();

if (isset($_POST['order_pay_btn'])) {
    $order_status = $_POST['order_status'];
    $total_order_price = $_POST['total_order_price'];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2JlPb5Xx6l9R8Po4gycWE3kwok9zcO+pgSx3Xxs3XB1rFN7B5y5t" crossorigin="anonymous">
</head>
<body>
    <section class="my-5 py-5">
        <div class="container text-center mt-3 pt-5">
            <h2 class="form-weight-bold">Payment</h2>
            <hr class="mx-auto">
        </div>

        <?php
        include('gateway-config.php');
        use Razorpay\Api\Api;

        $api = new Api($keyId, $keySecret);

        if (isset($_POST['order_status']) && $_POST['order_status'] == "not paid") {
            $amount = strval($_POST['total_order_price']);
            $order_id = $_POST['order_id'];
        ?>
            <div class="container text-center">
                <p>Total payment: $<?php echo $_POST['total_order_price']; ?></p>
                <form action="complete_payment.php" method="POST">
                    <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                    <input type="hidden" name="amount" value="<?php echo $amount; ?>">
                    <input class="btn btn-primary" type="submit" value="Pay Now">
                </form>
                <div id="paypal-button-container"></div>
            </div>
        <?php 
        } elseif (isset($_SESSION['calculateSubtotal']) && $_SESSION['calculateSubtotal'] != 0) {
            $amount = strval($_SESSION['calculateSubtotal']);
            $order_id = $_SESSION['order_id'];
        ?>
            <div class="container text-center">
                <p>Total payment: $<?php echo $_SESSION['calculateSubtotal']; ?></p>
                <form action="complete_payment.php" method="POST">
                    <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                    <input type="hidden" name="amount" value="<?php echo $amount; ?>">
                    <input class="btn btn-primary" type="submit" value="Pay Now">
                </form>
                <div id="paypal-button-container"></div>
            </div>
        <?php 
        } else { 
        ?>
            <p>You don't have an order</p>
        <?php 
        } 
        ?>

    </section>

    <!-- Include scripts -->
    <script src="js/jquery-3.7.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <script src="js/custom.js"></script>
</body>
</html>
