<?php
session_start();

// Function to calculate subtotal of the cart
function calculateSubtotal() {
    $subtotal = 0;
    if(isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $product) {
            $subtotal += (float)$product['product_price'] * (int)$product['product_quantity'];
        }
    }
    return $subtotal;
}

// Function to calculate total of the cart
function calculateTotal() {
    return calculateSubtotal();
}

// Add product to cart
if(isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];
    $product_array = array(
        'product_id' => $product_id,
        'product_title' => $_POST['product_title'],
        'product_price' => $_POST['product_price'],
        'product_quantity' => $_POST['product_quantity'],
    );

    // If cart is not empty and product already exists, update quantity
    if(isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id]['product_quantity'] += $product_array['product_quantity'];
    } else {
        $_SESSION['cart'][$product_id] = $product_array;
    }

    header('Location: ' . $_SERVER['HTTP_REFERER']);
    exit;
}

// Remove product from cart
if(isset($_POST['remove_product'])) {
    $product_id = $_POST['product_id'];
    if(isset($_SESSION['cart'][$product_id])) {
        unset($_SESSION['cart'][$product_id]);
    }
    header('Location: cart.php');
    exit;
}

// Edit quantity of product in cart
if(isset($_POST['edit_quantity'])) {
    $product_id = $_POST['product_id'];
    $product_quantity = $_POST['product_quantity'];
    if($product_quantity > 0) {
        $_SESSION['cart'][$product_id]['product_quantity'] = $product_quantity;
    } else {
        unset($_SESSION['cart'][$product_id]);
    }
    header('Location: cart.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
</head>
<body>
    <h2>Shopping Cart</h2>
   
   <table class="mt-5 pt-5">
    <tr>
        <th>Product</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Subtotal</th>
        <th>Action</th>
    </tr>
        <?php foreach($_SESSION['cart'] as $product): ?>
        <tr>
            <td><?php echo $product['product_title']; ?></td>
            <td><?php echo $product['product_price']; ?></td>
            <td>
                <form action="cart.php" method="post">
                    <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
                    <input type="number" name="product_quantity" value="<?php echo $product['product_quantity']; ?>">
                    <input type="submit" name="edit_quantity" value="Update">
                </form>
            </td>
            <td><?php echo $product['product_price'] * $product['product_quantity']; ?></td>
            <td>
                <form action="cart.php" method="post">
                    <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
                    <input type="submit" name="remove_product" value="Remove">
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        <tr>
            <td colspan="3">Total</td>
            <td colspan="2"><?php echo calculateTotal(); ?></td>
        </tr>
    </table>
</body>
</html>

<?php
include ('admin/_dbconnect.php');
include ('function/function_connect.php');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="x-UA-Compatiable" content="IE=edge">
    <meta name="viewport" content="width=device-width", initial-scale="1.0">
    <title>project</title>
    <!--bootstrap css-->
    <link rel="stylesheet" href="css/bootstrap.min.css.map">
    <!--font awesome icons-->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <!--font-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@800&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="media.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
</head>
<body>
<nav class="navbar navbar-expand-lg fixed-top fs-4 bg-body-tertiary">
  <div class="container-fluid">
  <img src="../project/img/logo.jpg" alt="logo" class="logo">
    <a class="navbar-brand" href="#"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarScroll">
      <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Product</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Login</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            About us
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">link 1</a></li>
            <li><a class="dropdown-item" href="#">link 2</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">link 3</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link " aria-disabled="true">Contact</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " aria-disabled="true"><i class="fa-solid fa-cart-shopping"></i>cart</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " aria-disabled="true">Total price:</a>
      </li>
     </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="" aria-label="Search">
        <button class="btn btn-outline-primary rounded-pill" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
<?php
// Check if product_id is set in the URL
if(isset($_GET['product_id'])) {
  // Get the product_id from the URL
  $product_id = $_GET['product_id'];
  
  // Fetch the product details from the database using the product_id
  $select_query = "SELECT * FROM `products` WHERE product_id = $product_id";
  $result_query = mysqli_query($conn, $select_query);
  
  // Check if the product exists
  if(mysqli_num_rows($result_query) > 0) {
      // Product exists, fetch its details
      $row = mysqli_fetch_assoc($result_query);
     
      $product_title = $row['product_title'];
      $product_category = $row['product_category'];
      $product_description = $row['product_description'];
      $product_image1 = $row['product_image1'];
      $product_image2 = $row['product_image2'];
      $product_image3 = $row['product_image3'];
      $product_image4 = $row['product_image4'];
      $product_price = $row['product_price'];
      $product_quantity= $row['product_quantity'];?>
    
      <section class="singleproduct my-5 pt-3">
        <div class="row mt-7">
          <div class="col-lg-4 col-md-6 col-sm-12">
            <div id="zoom-container">  
              <img class="img-fluid w-96 h-80 pb-2 p-5" src="./admin/productimg/<?php echo $product_image1; ?>" id="mainimg"/>
            </div>
            <div class="small-img-group">
              <div class="small-img-col">
                <img src="./admin/productimg/<?php echo $product_image2; ?>" width="100" class="small-img">
              </div>
              <div class="small-img-col">
                <img src="./admin/productimg/<?php echo $product_image3; ?>" width="100" class="small-img">
              </div>
              <div class="small-img-col">
                <img src="./admin/productimg/<?php echo $product_image4; ?>" width="100" class="small-img">
              </div>
              <div class="small-img-col">
                <img src="./admin/productimg/<?php echo $product_image1; ?>" width="100" class="small-img">
              </div>
            </div>
          </div> 
          <div class="col-lg-5 col-md-12 col-12">
            <h3><?php echo $product_title; ?></h3>
            <h3 class="py-4"><?php echo $product_category; ?></h3>
            <h2><i class="fa-solid fa-indian-rupee-sign"></i><?php echo $product_price; ?></h2>
            <form method="post" action="cart.php">
    <input type="hidden" name="product_id" value="<?php echo $product_id; ?>"/>
    <input type="hidden" name="product_image1" value="<?php echo $product_image1; ?>"/>
    <input type="hidden" name="product_title" value="<?php echo $product_title; ?>"/>
    <input type="hidden" name="product_price" value="<?php echo $product_price; ?>"/> <!-- Add this line -->
    <input type="hidden" name="product_quantity" value="<?php echo $product_quantity; ?>"/>
    <button class='btn btn-primary' type="submit" name="add_to_cart">Add to Cart</button>
</form>

            <h4 class="mt-5 mb-5">Product Details</h4>
            <span><?php echo $product_description; ?></span>
          </div>
        </div>
      </section>
      <?php
  } else {
    // Product not found
    echo "Product not found.";
  }
} else {
  // product_id not set in the URL
  echo "Product ID not provided.";
}
?>

<!-- jquery-->
<script src="js/jquery-3.7.1.js"></script>
<!--bootstrap js-->
<!-- <script src=" js/bootstrap.bundle.min.js"></script>-->
<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>-->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.s" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
<script src="zoom.js"></script>
<!--custom js-->
<script>
 var mainImg = document.getElementById("mainimg");
 var smallimg = document.getElementsByClassName("small-img");
for( let i=0;i<4;i++){
    smallimg[i].onclick = function(){
    mainImg.src = smallimg[i].src;
   }
}
//zoom
const image = document.getElementById('mainimg');

  image.addEventListener('mouseenter', () => {
    image.classList.add('zoomed');
  });

  image.addEventListener('mouseleave', () => {
    image.classList.remove('zoomed');
  });
</script>
</body>
</html>

