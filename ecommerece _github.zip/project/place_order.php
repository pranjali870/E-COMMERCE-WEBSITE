<?php
session_start();

include('_dbconnect.php');
if(!isset($_SESSION['logged_in'])){
    header('location: checkout.php?message=please login/sign up to place order' );
    exit;
    
}else{

if(isset($_POST['place_order'])) {
    //get user info and store it in database
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $city = $_POST['city'];
    $address = $_POST['address'];
    $order_cost = $_SESSION['calculateSubtotal'];
    $order_status ="not paid";
    $user_id = $_SESSION['user_id'];
    $order_date = date('y-m-d H:i:s');

    // Prepare and execute the query to insert order information
    $stmt = $conn->prepare("INSERT INTO orders (order_cost,order_status,user_id,user_phone,user_city,user_address,order_date) VALUES(?,?,?,?,?,?,?);");
    $stmt->bind_param('isiisss', $order_cost, $order_status, $user_id, $phone, $city, $address, $order_date);
    $stmt_status = $stmt->execute();
     if(!$stmt_status){
        header('location: index.php');
        exit;
     }
    // Get the order ID
    $order_id = $stmt->insert_id;

    // Store each item in the order_items table
    foreach($_SESSION['cart'] as  $key => $value) {
        $product = $_SESSION['cart'][$key];
        $product_id = $product['product_id'];
        $product_title =$product['product_title'];
        $product_image1 = $product['product_image1'];
        $product_price = $product['product_price'];
        $product_quantity = $product['product_quantity'];

        // Prepare and execute the query to insert order item information
        $stmt1 = $conn->prepare("INSERT INTO order_items (order_id,product_id,product_name,product_image1,product_price,product_quantity,user_id,order_date) VALUES (?,?,?,?,?,?,?,?)");
        $stmt1->bind_param('iissiiis', $order_id, $product_id, $product_title, $product_image1, $product_price, $product_quantity, $user_id, $order_date);
        $stmt1->execute();
    }
    $_SESSION['order_id'] = $order_id;
    // Inform user whether everything is fine or there is a problem
    header('Location: payment.php?order_status = order placed successfully');
    exit(); // Stop further execution
}
}
?>
